﻿namespace FishNet.CodeGenerating.Helping
{
    public enum SyncType
    {
        Unset,
        Variable,
        List,
        Dictionary,
        HashSet,
        Custom,
        Unhandled,
    }

}