﻿using FishNet.Managing.Timing;
using MonoFN.Cecil;
using System;
using UnityEngine;

namespace FishNet.CodeGenerating.Helping
{

    internal class TimeManagerHelper : CodegenBase
    {

        #region Reflection references.
        #endregion

        public override bool ImportReferences()
        {
            return true;
        }


    }
}
