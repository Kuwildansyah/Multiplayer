# Edgegap Servers Plugin Changelog

Please refer to our [Github repository](https://github.com/edgegap/edgegap-unity-plugin/releases) for up-to-date changelog.
