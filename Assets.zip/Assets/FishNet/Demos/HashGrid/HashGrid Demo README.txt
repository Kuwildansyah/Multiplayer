- Open scene.
- Press Play.

Demo only works on clientHost. Real usage works with separate client and server, and clientHost.
Scene view can be used to see objects appear and disappear as the player object moves betwen grid spots.