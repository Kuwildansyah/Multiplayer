﻿// namespace FishNet.Managing.Object //Remove in V5
// {
//     public enum SpawnParentType : byte
//     {
//         Unset = 0,
//         NetworkObject = 1,
//         NetworkBehaviour = 2
//     }
//
// }